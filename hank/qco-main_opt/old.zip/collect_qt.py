"""
collect_qt.py  —  collect Q_T results from all fixed-angle runs.

For each output file produced by:
    python main.py -n_of_generators 1 -d 2 -t T -sample_size 1
        -gates_path clifford.txt -fixed_gate_angle <angle>

reads the norms file, computes:
    delta  = max norm across all representation weights
    Q_T    = log(|C|) / log(1 / delta)

and writes one row per angle to a results file:
    angle  delta  Q_T

Usage:
    python collect_qt.py [options]

Options:
    --dir DIR       Directory containing the output .txt files  [default: ./]
    --t T           Value of t used in the runs                 [default: 100]
    --clifford N    Size of the Clifford group                  [default: 24]
    --out FILE      Output file path           [default: qt_results.txt]
"""

import argparse
import glob
import math
import os
import re
import sys
import numpy as np


def parse_args():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--dir',       default='./',   help='Directory with output files')
    p.add_argument('--t',         default=100,    type=int)
    p.add_argument('--clifford',  default=24,     type=int,
                   help='Number of elements in the free group C')
    p.add_argument('--out',       default='qt_results.txt')
    return p.parse_args()


def find_norms_files(directory, t):
    """
    Match files of the form  qcoN*T{t}angle*f1*s0*.txt
    (but NOT the -gates.txt files).
    """
    pattern = os.path.join(directory, f'qcoN*T{t}angle*f1*s0*.txt')
    files = [f for f in glob.glob(pattern) if not f.endswith('-gates.txt')]
    return files


def extract_angle(path):
    """Pull the angle value out of the filename."""
    m = re.search(r'angle([0-9.eE+\-]+)', os.path.basename(path))
    if m is None:
        return None
    return float(m.group(1))


def read_norms_file(path):
    """
    Returns (weights, delta) where delta = max norm across all weights.
    File format:
        [w1] [w2] ...      <- header line with weight labels
        v1   v2   ...      <- one row of norm values (sample_size=1 → exactly 1 row)
    """
    with open(path) as f:
        lines = [l.strip() for l in f if l.strip()]

    if len(lines) < 2:
        raise ValueError(f"Unexpected file format in {path}")

    # Parse weight labels from header
    weights = re.findall(r'\[([^\]]+)\]', lines[0])

    # Parse norm values — may be multiple rows if sample_size > 1; take max over rows
    all_deltas = []
    for line in lines[1:]:
        vals = [float(x) for x in line.split()]
        if vals:
            all_deltas.append(max(vals))

    delta = max(all_deltas)
    return weights, delta


def compute_qt(delta, clifford_size):
    """Q_T = log(|C|) / log(1/delta)"""
    if delta <= 0:
        return float('inf')
    if delta >= 1:
        return float('nan')
    return math.log(clifford_size) / math.log(1.0 / delta)


def main():
    args = parse_args()

    files = find_norms_files(args.dir, args.t)
    if not files:
        print(f"No matching files found in '{args.dir}' for t={args.t}.", file=sys.stderr)
        print("Expected pattern: qcoN*T{t}angle*f1*s0*.txt", file=sys.stderr)
        sys.exit(1)

    print(f"Found {len(files)} result files.", file=sys.stderr)

    rows = []
    skipped = 0
    for path in files:
        angle = extract_angle(path)
        if angle is None:
            print(f"  [WARN] Could not parse angle from {path}", file=sys.stderr)
            skipped += 1
            continue
        try:
            weights, delta = read_norms_file(path)
        except Exception as e:
            print(f"  [WARN] Could not read {path}: {e}", file=sys.stderr)
            skipped += 1
            continue

        qt = compute_qt(delta, args.clifford)
        rows.append((angle, delta, qt))

    if skipped:
        print(f"Skipped {skipped} files due to errors.", file=sys.stderr)

    # Sort by angle
    rows.sort(key=lambda r: r[0])

    out_path = os.path.join(args.dir, args.out) if not os.path.isabs(args.out) else args.out
    with open(out_path, 'w') as f:
        f.write(f"# Q_T results: Clifford+P(angle*pi), t={args.t}, |C|={args.clifford}\n")
        f.write(f"# Columns: angle  delta  Q_T\n")
        for angle, delta, qt in rows:
            f.write(f"{angle:.18f}  {delta:.18f}  {qt:.10f}\n")

    print(f"Wrote {len(rows)} rows to: {out_path}", file=sys.stderr)

    # Quick summary
    if rows:
        qt_vals = [r[2] for r in rows]
        best = min(rows, key=lambda r: r[2])
        worst = max(rows, key=lambda r: r[2])
        opt = math.log(args.clifford) / math.log(args.clifford / (2 * math.sqrt(args.clifford - 1)))
        print(f"\nSummary:", file=sys.stderr)
        print(f"  Q_T optimal (lower bound): {opt:.4f}", file=sys.stderr)
        print(f"  Best  Q_T: {best[2]:.4f}  at angle = {best[0]:.6f} (= {best[0]}*pi)", file=sys.stderr)
        print(f"  Worst Q_T: {worst[2]:.4f}  at angle = {worst[0]:.6f} (= {worst[0]}*pi)", file=sys.stderr)
        print(f"  Mean  Q_T: {np.mean(qt_vals):.4f}", file=sys.stderr)


if __name__ == '__main__':
    main()
